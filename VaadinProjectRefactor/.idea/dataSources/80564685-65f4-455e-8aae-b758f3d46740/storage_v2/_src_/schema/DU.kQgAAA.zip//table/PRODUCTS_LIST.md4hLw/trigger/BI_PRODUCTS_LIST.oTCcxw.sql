create trigger BI_PRODUCTS_LIST
  before insert
  on PRODUCTS_LIST
  for each row
  begin   
  if :NEW."ID" is null then 
    select "DEMO_CUST_SEQ".nextval into :NEW."ID" from dual; 
  end if; 
end;
/

