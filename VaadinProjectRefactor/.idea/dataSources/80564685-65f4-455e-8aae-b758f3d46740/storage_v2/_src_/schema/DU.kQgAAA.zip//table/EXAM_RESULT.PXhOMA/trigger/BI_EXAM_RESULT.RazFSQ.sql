create trigger BI_EXAM_RESULT
  before insert
  on EXAM_RESULT
  for each row
  begin   
  if :NEW."ID" is null then 
    select "DEMO_CUST_SEQ".nextval into :NEW."ID" from dual; 
  end if; 
end;
/

